<?php

header("Location: ./views/login.php");
exit;
