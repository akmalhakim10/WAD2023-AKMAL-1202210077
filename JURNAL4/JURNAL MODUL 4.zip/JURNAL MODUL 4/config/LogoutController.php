<?php 

// (1) Hapus cookie dengan key id 

// 

// (2) Mulai session

//

// (3) Hapus semua session yang berlangsung

//

// (4) Lakukan redirect ke halaman login awal

//

exit;

?>